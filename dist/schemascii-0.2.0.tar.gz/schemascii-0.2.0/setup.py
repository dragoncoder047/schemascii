from setuptools import setup
setup(
    packages=["schemascii"]
)
